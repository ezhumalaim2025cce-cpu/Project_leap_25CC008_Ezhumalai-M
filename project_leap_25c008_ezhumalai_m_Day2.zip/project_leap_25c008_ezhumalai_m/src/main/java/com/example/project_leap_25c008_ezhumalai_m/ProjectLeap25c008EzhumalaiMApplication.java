package com.example.project_leap_25c008_ezhumalai_m;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectLeap25c008EzhumalaiMApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectLeap25c008EzhumalaiMApplication.class, args);
	}

}
