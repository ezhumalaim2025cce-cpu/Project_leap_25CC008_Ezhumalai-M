package com.example.project_leap_25c008_ezhumalai_m;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectLeap25c008EzhumalaiMApplicationTests {

	@Test
	void contextLoads() {
	}

}
